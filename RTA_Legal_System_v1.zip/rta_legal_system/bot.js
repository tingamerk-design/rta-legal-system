require("dotenv").config();
const { Client, GatewayIntentBits, EmbedBuilder } = require("discord.js");
const { Pool } = require("pg");
const pool = new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.NODE_ENV==="production"?{rejectUnauthorized:false}:false});
const client = new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMembers]});

client.once("ready",()=>console.log(`RTA Bot online as ${client.user.tag}`));
client.on("guildMemberAdd", async member=>{
  if(member.guild.id!==process.env.DISCORD_GUILD_ID) return;
  try {
    await pool.query("UPDATE users SET discord_username=$1,discord_avatar=$2 WHERE discord_user_id=$3",
      [member.user.tag,member.user.displayAvatarURL(),member.id]);
    const channel=await client.channels.fetch(process.env.DISCORD_NOTIFICATION_CHANNEL_ID).catch(()=>null);
    if(channel) channel.send(`สมาชิก Discord ใหม่: **${member.user.tag}**`);
  } catch(e){console.error("member sync failed",e.message);}
});
client.on("interactionCreate",async interaction=>{
  if(!interaction.isChatInputCommand()) return;
  if(interaction.commandName==="กฎหมาย"){
    const term=interaction.options.getString("ค้นหา");
    const r=await pool.query("SELECT title,law_number,category FROM laws WHERE status='published' AND (title ILIKE $1 OR COALESCE(law_number,'') ILIKE $1) LIMIT 5",[`%${term}%`]);
    const desc=r.rows.length?r.rows.map(x=>`**${x.law_number||"-"} ${x.title}** · ${x.category}`).join("\n"):"ไม่พบกฎหมายที่ตรงกับคำค้น";
    await interaction.reply({embeds:[new EmbedBuilder().setTitle("ค้นหากฎหมาย RTA").setDescription(desc).setColor(0xC69B42)],ephemeral:true});
  }
});
client.login(process.env.DISCORD_TOKEN);
