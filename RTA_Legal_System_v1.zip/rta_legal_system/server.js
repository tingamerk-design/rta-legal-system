require("dotenv").config();
const express = require("express");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const { Pool } = require("pg");
const fs = require("fs");
const path = require("path");

const app = express();
const pool = new Pool({ connectionString: process.env.DATABASE_URL, ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false });
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "2mb" }));
app.use(express.urlencoded({ extended: true }));
app.use(session({
  store: new PgSession({ pool, createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET || "development-only-change-this",
  resave: false, saveUninitialized: false,
  cookie: { httpOnly: true, sameSite: "lax", secure: process.env.NODE_ENV === "production", maxAge: 1000*60*60*12 }
}));
app.use(express.static(path.join(__dirname, "public")));

const q = (sql, params=[]) => pool.query(sql, params);
const asyncRoute = fn => (req,res,next) => Promise.resolve(fn(req,res,next)).catch(next);
const loggedIn = (req,res,next) => req.session.user ? next() : res.status(401).json({error:"กรุณาเข้าสู่ระบบ"});
const adminOnly = (req,res,next) => req.session.user?.is_admin ? next() : res.status(403).json({error:"ไม่มีสิทธิ์ผู้ดูแล"});
async function audit(req, action, type, id, details="") {
  await q("INSERT INTO audit_logs(user_id,action,entity_type,entity_id,details) VALUES($1,$2,$3,$4,$5)",
    [req.session.user?.id || null, action, type, String(id ?? ""), details]);
}
function publicUser(u) {
  return {id:u.id, username:u.username, discord_username:u.discord_username, discord_avatar:u.discord_avatar,
    in_game_name:u.in_game_name, rank_name:u.rank_name, unit_name:u.unit_name, position_name:u.position_name,
    role_names:u.role_names, is_admin:u.is_admin};
}

app.get("/api/health", (req,res)=>res.json({ok:true, service:"RTA Legal System"}));
app.get("/api/me", (req,res)=>res.json({user:req.session.user || null}));

app.post("/api/register", asyncRoute(async(req,res)=>{
  const {username,password} = req.body;
  if (!/^[a-zA-Z0-9_]{4,40}$/.test(username||"") || (password||"").length < 8)
    return res.status(400).json({error:"ชื่อผู้ใช้ต้องมี 4-40 ตัวอักษร และรหัสผ่านอย่างน้อย 8 ตัว"});
  const hash = await bcrypt.hash(password, 12);
  try {
    const r = await q("INSERT INTO users(username,password_hash) VALUES($1,$2) RETURNING *",[username,hash]);
    req.session.user = publicUser(r.rows[0]);
    res.json({user:req.session.user});
  } catch(e) { if(e.code==="23505") return res.status(409).json({error:"ชื่อผู้ใช้นี้ถูกใช้แล้ว"}); throw e; }
}));
app.post("/api/login", asyncRoute(async(req,res)=>{
  const r = await q("SELECT * FROM users WHERE username=$1 AND is_active=true",[req.body.username]);
  if(!r.rowCount || !(await bcrypt.compare(req.body.password||"",r.rows[0].password_hash)))
    return res.status(401).json({error:"ชื่อผู้ใช้หรือรหัสผ่านไม่ถูกต้อง"});
  req.session.user = publicUser(r.rows[0]); res.json({user:req.session.user});
}));
app.post("/api/logout",(req,res)=>req.session.destroy(()=>res.json({ok:true})));

app.get("/api/laws", asyncRoute(async(req,res)=>{
  const term = `%${String(req.query.q||"").slice(0,100)}%`;
  const r = await q(`SELECT l.*, (SELECT COUNT(*) FROM articles a WHERE a.law_id=l.id AND a.status='active') AS article_count
    FROM laws l WHERE l.status='published' AND (l.title ILIKE $1 OR COALESCE(l.law_number,'') ILIKE $1 OR l.category ILIKE $1)
    ORDER BY l.updated_at DESC`,[term]);
  res.json(r.rows);
}));
app.get("/api/laws/:id", asyncRoute(async(req,res)=>{
  const r=await q("SELECT * FROM laws WHERE id=$1 AND status='published'",[req.params.id]);
  if(!r.rowCount) return res.status(404).json({error:"ไม่พบกฎหมาย"});
  const a=await q("SELECT id,article_number,title,content,penalty FROM articles WHERE law_id=$1 AND status='active' ORDER BY sort_order,id",[req.params.id]);
  res.json({...r.rows[0],articles:a.rows});
}));
app.get("/api/announcements",asyncRoute(async(req,res)=>{
  const r=await q("SELECT id,title,body,category,created_at FROM announcements WHERE status='published' AND (audience='all' OR $1=ANY(string_to_array(audience,','))) ORDER BY created_at DESC LIMIT 50",[req.session.user?.role_names?.join(",")||"public"]);
  res.json(r.rows);
}));

app.get("/api/admin/summary",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const r=await q(`SELECT (SELECT COUNT(*) FROM users) users,(SELECT COUNT(*) FROM laws) laws,
    (SELECT COUNT(*) FROM cases) cases,(SELECT COUNT(*) FROM warrants) warrants,
    (SELECT COUNT(*) FROM announcements) announcements`);
  res.json(r.rows[0]);
}));
app.post("/api/admin/laws",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const {law_number,title,category,content,penalty,promulgation_date,promulgating_authority,status,publish_at}=req.body;
  if(!title||!category) return res.status(400).json({error:"กรุณาระบุชื่อกฎหมายและหมวดหมู่"});
  const r=await q(`INSERT INTO laws(law_number,title,category,content,penalty,promulgation_date,promulgating_authority,status,publish_at,created_by)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10) RETURNING *`,
    [law_number,title,category,content||"",penalty||"",promulgation_date||null,promulgating_authority||"",status||"draft",publish_at||null,req.session.user.id]);
  await audit(req,"create","law",r.rows[0].id,title); res.json(r.rows[0]);
}));
app.put("/api/admin/laws/:id",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const {title,law_number,category,content,penalty,status,publish_at}=req.body;
  const r=await q(`UPDATE laws SET title=$1,law_number=$2,category=$3,content=$4,penalty=$5,status=$6,publish_at=$7,updated_at=NOW()
    WHERE id=$8 RETURNING *`,[title,law_number,category,content,penalty,status,publish_at||null,req.params.id]);
  if(!r.rowCount) return res.status(404).json({error:"ไม่พบข้อมูล"});
  await audit(req,"update","law",req.params.id,title); res.json(r.rows[0]);
}));
app.post("/api/admin/articles",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const {law_id,article_number,title,content,penalty,sort_order}=req.body;
  const r=await q(`INSERT INTO articles(law_id,article_number,title,content,penalty,sort_order)
    VALUES($1,$2,$3,$4,$5,$6) RETURNING *`,[law_id,article_number,title||"",content,penalty||"",sort_order||0]);
  await audit(req,"create","article",r.rows[0].id,article_number); res.json(r.rows[0]);
}));
app.get("/api/admin/users",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const r=await q("SELECT id,username,discord_user_id,discord_username,in_game_name,rank_name,unit_name,position_name,role_names,is_admin,is_active,created_at FROM users ORDER BY created_at DESC");
  res.json(r.rows);
}));
app.patch("/api/admin/users/:id",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const {role_names,is_active,rank_name,unit_name,position_name}=req.body;
  const r=await q(`UPDATE users SET role_names=COALESCE($1,role_names),is_active=COALESCE($2,is_active),
    rank_name=COALESCE($3,rank_name),unit_name=COALESCE($4,unit_name),position_name=COALESCE($5,position_name)
    WHERE id=$6 AND is_admin=false RETURNING id,username,role_names,is_active,rank_name,unit_name,position_name`,
    [role_names,is_active,rank_name,unit_name,position_name,req.params.id]);
  if(!r.rowCount) return res.status(404).json({error:"ไม่พบสมาชิก หรือไม่อนุญาตให้แก้ไขแอดมินหลัก"});
  await audit(req,"update","user",req.params.id,"ปรับสิทธิ์สมาชิก"); res.json(r.rows[0]);
}));
app.get("/api/admin/cases",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const r=await q("SELECT * FROM cases ORDER BY created_at DESC"); res.json(r.rows);
}));
app.post("/api/admin/cases",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const b=req.body;
  const r=await q(`INSERT INTO cases(case_number,accused,complainant,accuser,judge,charges,related_articles,evidence_private,incident_date,hearing_date,status)
    VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11) RETURNING id,case_number,status`,
    [b.case_number,b.accused,b.complainant,b.accuser,b.judge,b.charges,b.related_articles,b.evidence_private,b.incident_date||null,b.hearing_date||null,b.status||"new"]);
  await audit(req,"create","case",r.rows[0].id,b.case_number); res.json(r.rows[0]);
}));
app.post("/api/admin/announcements",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const b=req.body;
  const r=await q("INSERT INTO announcements(title,body,category,audience,status,publish_at) VALUES($1,$2,$3,$4,$5,$6) RETURNING *",
    [b.title,b.body,b.category||"general",b.audience||"all",b.status||"draft",b.publish_at||null]);
  await audit(req,"create","announcement",r.rows[0].id,b.title); res.json(r.rows[0]);
}));
app.get("/api/admin/audit",loggedIn,adminOnly,asyncRoute(async(req,res)=>{
  const r=await q("SELECT a.*,u.username FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id ORDER BY a.created_at DESC LIMIT 200"); res.json(r.rows);
}));

// One-time bootstrap: set SETUP_KEY in hosting secrets, call this endpoint, then remove the key.
app.post("/setup-admin",asyncRoute(async(req,res)=>{
  if(!process.env.SETUP_KEY || req.body.setup_key!==process.env.SETUP_KEY) return res.status(403).json({error:"Setup key ไม่ถูกต้อง"});
  const count=await q("SELECT COUNT(*)::int n FROM users WHERE is_admin=true");
  if(count.rows[0].n>0) return res.status(409).json({error:"มีแอดมินหลักแล้ว"});
  const {username,password}=req.body;
  if(!/^[a-zA-Z0-9_]{4,40}$/.test(username||"") || (password||"").length<12) return res.status(400).json({error:"ชื่อผู้ใช้ 4-40 ตัว และรหัสผ่านอย่างน้อย 12 ตัว"});
  const hash=await bcrypt.hash(password,12);
  const r=await q("INSERT INTO users(username,password_hash,is_admin,role_names) VALUES($1,$2,true,ARRAY['admin']) RETURNING id,username,is_admin",[username,hash]);
  res.json({message:"สร้างแอดมินหลักแล้ว กรุณาลบ SETUP_KEY ออกจาก Environment Variables ทันที",admin:r.rows[0]});
}));

app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.use((err,req,res,next)=>{console.error(err);res.status(500).json({error:"เกิดข้อผิดพลาดในระบบ กรุณาตรวจสอบการตั้งค่าฐานข้อมูล"});});
const port=process.env.PORT||3000;
app.listen(port,()=>console.log(`RTA Legal System listening on ${port}`));
