require("dotenv").config();
const { REST, Routes, SlashCommandBuilder } = require("discord.js");
const commands=[new SlashCommandBuilder().setName("กฎหมาย").setDescription("ค้นหากฎหมาย RTA")
  .addStringOption(o=>o.setName("ค้นหา").setDescription("ชื่อหรือเลขกฎหมาย").setRequired(true))].map(x=>x.toJSON());
const rest=new REST({version:"10"}).setToken(process.env.DISCORD_TOKEN);
rest.put(Routes.applicationGuildCommands(process.env.DISCORD_CLIENT_ID,process.env.DISCORD_GUILD_ID),{body:commands})
 .then(()=>console.log("ลงทะเบียนคำสั่งสำเร็จ")).catch(console.error);
