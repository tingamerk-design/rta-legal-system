# มวลกฎหมาย RTA — คู่มือติดตั้งฉบับเริ่มต้น

## สิ่งที่อยู่ใน ZIP
- `public/` เว็บไซต์สมาชิกและหน้าแอดมินแบบ responsive
- `server.js` API, สมัครสมาชิก/เข้าสู่ระบบ, สิทธิ์แอดมิน, จัดการกฎหมาย/มาตรา/สมาชิก/คดี/ประกาศ
- `schema.sql` โครงสร้างฐานข้อมูล PostgreSQL
- `bot.js` Discord Bot เบื้องต้น: แจ้งสมาชิกใหม่และคำสั่งค้นหากฎหมาย
- `register-commands.js` ลงทะเบียนคำสั่ง Discord
- `.env.example` ตัวอย่างตัวแปรลับ
- `docs/` คู่มือและรายการงานที่ต้องตั้งค่า

## ข้อกำหนด
Node.js 20 ขึ้นไป และ PostgreSQL ที่เข้าถึงจากโฮสต์ได้

## ติดตั้งในเครื่องเพื่อทดสอบ
1. แตก ZIP
2. เปิดโฟลเดอร์โปรเจกต์ใน IDE/Terminal ที่รองรับ Node.js
3. คัดลอก `.env.example` เป็น `.env` แล้วใส่ `DATABASE_URL` และ `SESSION_SECRET`
4. สร้างฐานข้อมูล PostgreSQL แล้วรันไฟล์ `schema.sql`
5. รัน `npm install`
6. รัน `npm start`
7. เปิด `http://localhost:3000`

> Android อย่างเดียว: Chrome และ ZArchiver ใช้แตกไฟล์/เปิดเว็บได้ แต่การรัน Node.js และ PostgreSQL ต้องใช้บริการ Cloud IDE/Hosting ที่รองรับ ไม่สามารถเปิด ZIP แล้วให้ระบบหลังบ้านทำงานจาก Chrome หรือ ZArchiver โดยตรงได้

## สร้างแอดมินหลักคนแรก
1. ตั้ง `SETUP_KEY` ใน Environment Variables ของโฮสต์ให้เป็นค่าสุ่มยาว
2. ส่ง POST ไปที่ `/setup-admin` ด้วย JSON:
   `{"setup_key":"ค่าที่ตั้งไว้","username":"ชื่อผู้ดูแล","password":"รหัสผ่านยาวอย่างน้อย 12 ตัว"}`
3. เมื่อสำเร็จ ให้ลบ `SETUP_KEY` ออกจาก Environment Variables ทันที
4. เข้าหน้า `/admin` ด้วยบัญชีนี้
5. ระบบไม่อนุญาตให้สร้างแอดมินหลักซ้ำจาก endpoint นี้

## Discord
ดู `docs/DISCORD_SETUP_TH.md` ก่อนตั้ง Bot. ห้ามส่ง Bot Token, Database URL หรือ Session Secret ให้บุคคลอื่นหรือใส่ในไฟล์หน้าเว็บ

## ข้อจำกัดสำคัญของรุ่นเริ่มต้น
นี่คือโครงงาน Full-stack ที่เตรียมโครงสร้างและฟังก์ชันหลัก ไม่ใช่บริการที่เผยแพร่ขึ้นอินเทอร์เน็ตแล้ว:
- ต้องสร้าง PostgreSQL และตั้งค่า Environment Variables ก่อนใช้งานจริง
- Discord Role sync/OAuth ยังต้องตั้งค่าและพัฒนาตัวเชื่อม Discord API เพิ่มเติม; รุ่นนี้มีช่อง Discord ID/Role และ Bot skeleton แต่ยังไม่ใช่ระบบยืนยัน Role อัตโนมัติที่สมบูรณ์
- Push notification และ Email ยังเป็นส่วนที่ต้องเลือกผู้ให้บริการและตั้งค่า
- ระบบไฟล์หลักฐานยังเก็บเป็นข้อความในฐานข้อมูล ไม่ใช่ระบบอัปโหลดไฟล์เข้าคลังเอกสาร
- ต้องเพิ่ม CSRF protection, rate limiting, password reset, secure file storage, automated backups และทดสอบสิทธิ์ก่อนใช้กับข้อมูลจริง
- Session ใช้ PostgreSQL store; ตั้ง HTTPS เมื่อ Deploy
- กฎหมายทั้งหมดเป็นกฎหมายสมมติสำหรับแมพ RTA เท่านั้น ไม่ใช่คำแนะนำหรือกฎหมายไทยจริง

อย่าใส่ข้อมูลคดีหรือข้อมูลส่วนบุคคลจริงจนกว่าจะผ่านการทดสอบความปลอดภัย
