# Checklist ก่อนเผยแพร่จริง

- [ ] เลือก Node.js hosting และ PostgreSQL hosting ที่รองรับการใช้งานต่อเนื่อง
- [ ] สร้างฐานข้อมูลและนำเข้า schema.sql
- [ ] ตั้ง DATABASE_URL, SESSION_SECRET, NODE_ENV=production
- [ ] ตั้ง HTTPS และโดเมน
- [ ] สร้างแอดมินหลักด้วย SETUP_KEY แล้วลบ key
- [ ] ทดสอบสมัครสมาชิก/ล็อกอิน/ออกจากระบบ
- [ ] ทดสอบสิทธิ์ทุกกลุ่มและการปิดกั้นข้อมูลคดี
- [ ] เพิ่ม Discord Role sync ที่ตรวจ Role จาก Discord API ฝั่งเซิร์ฟเวอร์
- [ ] ตั้ง Discord Bot และทดสอบคำสั่ง/ประกาศ
- [ ] เพิ่มระบบอัปโหลดไฟล์หลักฐานแบบ private
- [ ] เพิ่ม PDF หมายศาลและระบบพิมพ์
- [ ] เพิ่ม Push และ Email
- [ ] เปิดสำรองฐานข้อมูลอัตโนมัติและทดสอบกู้คืน
- [ ] เพิ่ม rate limit, CSRF, password reset และบันทึกเหตุการณ์ความปลอดภัย
- [ ] ทดสอบบน Android และ Desktop
