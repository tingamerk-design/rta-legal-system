# คู่มือตั้ง Discord Bot (เบื้องต้น)

1. เปิด Discord Developer Portal: https://discord.com/developers/applications
2. สร้าง Application และเพิ่ม Bot
3. เปิด Server Members Intent เฉพาะเมื่อจำเป็น
4. เชิญ Bot เข้าเซิร์ฟเวอร์ด้วย OAuth2 URL Generator โดยเลือก `bot` และ `applications.commands`
5. ให้สิทธิ์เท่าที่จำเป็น เช่น View Channels, Send Messages, Embed Links และ Use Slash Commands
6. ตั้งค่า `DISCORD_TOKEN`, `DISCORD_GUILD_ID`, `DISCORD_NOTIFICATION_CHANNEL_ID`, `DISCORD_CLIENT_ID` ใน Environment Variables ของโฮสต์
7. รัน `npm run bot` เพื่อเปิด Bot
8. รัน `node register-commands.js` เพื่อลงทะเบียนคำสั่ง `/กฎหมาย`

## ข้อควรทราบ
- อย่าโพสต์ Token ในแชตหรือ GitHub
- Bot skeleton ปัจจุบันรองรับการแจ้งสมาชิกใหม่และคำสั่งค้นหากฎหมาย
- การตรวจ Discord Role แบบอัตโนมัติยังต้องเพิ่มฟังก์ชันตรวจสมาชิก/Role และผูก Discord User ID กับบัญชีเว็บไซต์อย่างปลอดภัย
- ควรทดสอบในเซิร์ฟเวอร์ทดลองก่อน
