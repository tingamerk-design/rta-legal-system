CREATE TABLE IF NOT EXISTS users (
 id BIGSERIAL PRIMARY KEY,
 username VARCHAR(40) UNIQUE NOT NULL,
 password_hash TEXT NOT NULL,
 discord_user_id VARCHAR(32) UNIQUE,
 discord_username TEXT,
 discord_avatar TEXT,
 in_game_name TEXT,
 rank_name TEXT,
 unit_name TEXT,
 position_name TEXT,
 role_names TEXT[] NOT NULL DEFAULT '{}',
 is_admin BOOLEAN NOT NULL DEFAULT FALSE,
 is_active BOOLEAN NOT NULL DEFAULT TRUE,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS laws (
 id BIGSERIAL PRIMARY KEY,
 law_number TEXT,
 title TEXT NOT NULL,
 category TEXT NOT NULL,
 content TEXT NOT NULL DEFAULT '',
 penalty TEXT DEFAULT '',
 promulgation_date DATE,
 promulgating_authority TEXT,
 status TEXT NOT NULL DEFAULT 'draft',
 publish_at TIMESTAMPTZ,
 created_by BIGINT REFERENCES users(id),
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS articles (
 id BIGSERIAL PRIMARY KEY,
 law_id BIGINT NOT NULL REFERENCES laws(id) ON DELETE CASCADE,
 article_number TEXT NOT NULL,
 title TEXT,
 content TEXT NOT NULL,
 penalty TEXT,
 status TEXT NOT NULL DEFAULT 'active',
 sort_order INT NOT NULL DEFAULT 0,
 updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS cases (
 id BIGSERIAL PRIMARY KEY,
 case_number TEXT UNIQUE NOT NULL,
 accused TEXT,
 complainant TEXT,
 accuser TEXT,
 judge TEXT,
 charges TEXT,
 related_articles TEXT,
 evidence_private TEXT,
 incident_date DATE,
 hearing_date TIMESTAMPTZ,
 verdict TEXT,
 penalty TEXT,
 status TEXT NOT NULL DEFAULT 'new',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS warrants (
 id BIGSERIAL PRIMARY KEY,
 warrant_number TEXT UNIQUE NOT NULL,
 case_number TEXT,
 person_name TEXT,
 charges TEXT,
 evidence_private TEXT,
 status TEXT NOT NULL DEFAULT 'active',
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS announcements (
 id BIGSERIAL PRIMARY KEY,
 title TEXT NOT NULL,
 body TEXT NOT NULL,
 category TEXT NOT NULL DEFAULT 'general',
 audience TEXT NOT NULL DEFAULT 'all',
 status TEXT NOT NULL DEFAULT 'draft',
 publish_at TIMESTAMPTZ,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE TABLE IF NOT EXISTS audit_logs (
 id BIGSERIAL PRIMARY KEY,
 user_id BIGINT REFERENCES users(id),
 action TEXT NOT NULL,
 entity_type TEXT,
 entity_id TEXT,
 details TEXT,
 created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
CREATE INDEX IF NOT EXISTS idx_laws_status ON laws(status);
CREATE INDEX IF NOT EXISTS idx_articles_law ON articles(law_id);
CREATE INDEX IF NOT EXISTS idx_cases_status ON cases(status);
CREATE INDEX IF NOT EXISTS idx_announcements_status ON announcements(status);
